package com.test;

import java.util.Arrays;
import java.util.List;

public class QuizApp {

    public static void main(String[] args) {
        List<Question> questions = Arrays.asList(
            new Question("What is the capital of France?", 
                         Arrays.asList("Paris", "London", "Berlin", "Madrid"), 
                         0),
            new Question("Which planet is known as the Red Planet?",
                         Arrays.asList("Earth", "Mars", "Jupiter", "Saturn"),
                         1),
            new Question("Which river is considered the holiest in India?",
                         Arrays.asList("Yamuna", "Ganges", "Narmada", "Godavari"),
                         1),
            new Question("Who was the first President of India?",
                         Arrays.asList("Jawaharlal Nehru", "S. Radhakrishnan", "Rajendra Prasad", "Babu Rajendra Prasad"),
                         2), 
            new Question("What is the national animal of India?",
                         Arrays.asList("Elephant", "Bengal Tiger", "Peacock", "Lion"),
                         1), 
            new Question("Which Indian state is known as the \"Land of Five Rivers\"?",
                         Arrays.asList("Punjab", "Gujarat", "Rajasthan", "Kerala"),
                         0),
            new Question("Who wrote the Indian national anthem \"Jana Gana Mana\"?",
                         Arrays.asList("Bankim Chandra Chatterjee", "Rabindranath Tagore", "Sarojini Naidu", "Subramania Bharati"),
                         1),
            new Question("Which Indian city is also known as the \"Silicon Valley of India\"?",
                         Arrays.asList("Mumbai", "Hyderabad", "Chennai", "Bengaluru"),
                         3), 
            new Question("Which festival is known as the \"Festival of Lights\" in India?",
                         Arrays.asList("Holi", "Diwali", "Eid", "Christmas"),
                         1), 
            new Question("Which is the largest state in India by area?",
                         Arrays.asList("Maharashtra", "Uttar Pradesh", "Rajasthan", "Madhya Pradesh"),
                         2)
        );

        Quiz quiz = new Quiz(questions);
        quiz.start();
    }
}
